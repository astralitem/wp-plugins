(function () {
	'use strict';

	const cardsRoot = document.querySelector('[data-zzz-cards]');
	const allCards = Array.from(document.querySelectorAll('[data-zzz-card]'));
	if (allCards.length === 0) {
		return;
	}

	const filtersRoot = document.querySelector('[data-zzz-filters]');

	const closeAllHovers = () => {
		allCards.forEach((card) => {
			card.querySelectorAll('[data-zzz-hover].is-open').forEach((openItem) => {
			openItem.classList.remove('is-open');
			});
		});
	};

	document.querySelectorAll('[data-zzz-hover-trigger]').forEach((trigger) => {
		trigger.addEventListener('click', (event) => {
			event.preventDefault();
			const item = trigger.closest('[data-zzz-hover]');
			if (!item) {
				return;
			}

			const isOpen = item.classList.contains('is-open');
			closeAllHovers();
			if (!isOpen) {
				item.classList.add('is-open');
			}
		});
	});

	document.addEventListener('click', (event) => {
		if (!event.target.closest('[data-zzz-card]')) {
			closeAllHovers();
		}
	});

	allCards.forEach((card) => {
		const tabTriggers = card.querySelectorAll('[data-zzz-tab-trigger]');
		const panels = card.querySelectorAll('[data-zzz-tab-panel]');

		tabTriggers.forEach((trigger) => {
			trigger.addEventListener('click', () => {
				const target = trigger.getAttribute('data-target');
				if (!target) {
					return;
				}

				tabTriggers.forEach((item) => {
					item.classList.remove('is-active');
					item.setAttribute('aria-selected', 'false');
				});
				trigger.classList.add('is-active');
				trigger.setAttribute('aria-selected', 'true');

				panels.forEach((panel) => {
					const isTarget = panel.getAttribute('data-zzz-tab-panel') === target;
					panel.classList.toggle('is-active', isTarget);
					panel.hidden = !isTarget;
				});
			});
		});

		card.querySelectorAll('[data-zzz-gallery]').forEach((gallery) => {
			const track = gallery.querySelector('[data-zzz-gallery-track]');
			const slides = gallery.querySelectorAll('.zzz-gallery__slide');
			const prevBtn = gallery.querySelector('[data-zzz-gallery-prev]');
			const nextBtn = gallery.querySelector('[data-zzz-gallery-next]');

			if (!track || slides.length <= 1 || !prevBtn || !nextBtn) {
				return;
			}

			let index = 0;
			const total = slides.length;
			const isRtl = window.getComputedStyle(gallery).direction === 'rtl';
			const render = () => {
				const directionMultiplier = isRtl ? 100 : -100;
				track.style.transform = `translateX(${index * directionMultiplier}%)`;
			};

			prevBtn.addEventListener('click', () => {
				index = (index - 1 + total) % total;
				render();
			});

			nextBtn.addEventListener('click', () => {
				index = (index + 1) % total;
				render();
			});

			render();
		});
	});

	if (!cardsRoot || !filtersRoot) {
		return;
	}

	const cards = Array.from(cardsRoot.querySelectorAll('[data-zzz-card]'));
	const authorityMin = filtersRoot.querySelector('[data-zzz-filter="authority-min"]');
	const authorityMax = filtersRoot.querySelector('[data-zzz-filter="authority-max"]');
	const serverInput = filtersRoot.querySelector('[data-zzz-filter="server"]');
	const priceMin = filtersRoot.querySelector('[data-zzz-filter="price-min"]');
	const priceMax = filtersRoot.querySelector('[data-zzz-filter="price-max"]');
	const sortInput = filtersRoot.querySelector('[data-zzz-filter="sort"]');
	const characterChecks = Array.from(filtersRoot.querySelectorAll('[data-zzz-filter="character"]'));
	const discChecks = Array.from(filtersRoot.querySelectorAll('[data-zzz-filter="disc"]'));

	const readJson = (raw) => {
		if (!raw) {
			return [];
		}
		try {
			const parsed = JSON.parse(raw);
			return Array.isArray(parsed) ? parsed : [];
		} catch (error) {
			return [];
		}
	};

	const selectedFrom = (inputs) =>
		inputs.filter((input) => input.checked).map((input) => input.value.trim()).filter(Boolean);


	const runFiltersWithoutJump = () => {
		const previousY = window.scrollY;
		applyFilters();
		if (Math.abs(window.scrollY - previousY) > 4) {
			window.scrollTo({ top: previousY, behavior: 'auto' });
		}
	};
	const applyFilters = () => {
		const authMin = Math.max(1, Math.min(60, parseInt(authorityMin?.value || '1', 10) || 1));
		const authMax = Math.max(1, Math.min(60, parseInt(authorityMax?.value || '60', 10) || 60));
		const minAuth = Math.min(authMin, authMax);
		const maxAuth = Math.max(authMin, authMax);
		const selectedServer = (serverInput?.value || '').trim();
		const minPrice = parseFloat(priceMin?.value || '0') || 0;
		const maxPriceInput = parseFloat(priceMax?.value || '0') || 0;
		const maxPrice = maxPriceInput > 0 ? maxPriceInput : Number.MAX_SAFE_INTEGER;
		const selectedCharacters = selectedFrom(characterChecks);
		const selectedDiscs = selectedFrom(discChecks);
		const sortBy = sortInput?.value || 'newest';

		const visible = [];
		cards.forEach((card) => {
			const authority = parseInt(card.getAttribute('data-authority-level') || '0', 10) || 0;
			const server = (card.getAttribute('data-server') || '').trim();
			const price = parseFloat(card.getAttribute('data-price') || '0') || 0;
			const characters = readJson(card.getAttribute('data-characters'));
			const discs = readJson(card.getAttribute('data-discs'));

			const authorityMatch = authority >= minAuth && authority <= maxAuth;
			const serverMatch = !selectedServer || selectedServer === server;
			const priceMatch = price >= minPrice && price <= maxPrice;
			const characterMatch = selectedCharacters.every((value) => characters.includes(value));
			const discMatch = selectedDiscs.every((value) => discs.includes(value));

			const isMatch = authorityMatch && serverMatch && priceMatch && characterMatch && discMatch;
			card.style.display = isMatch ? '' : 'none';
			if (isMatch) {
				visible.push(card);
			}
		});

		visible.sort((a, b) => {
			const createdA = parseInt(a.getAttribute('data-created-at') || '0', 10) || 0;
			const createdB = parseInt(b.getAttribute('data-created-at') || '0', 10) || 0;
			const priceA = parseFloat(a.getAttribute('data-price') || '0') || 0;
			const priceB = parseFloat(b.getAttribute('data-price') || '0') || 0;

			if (sortBy === 'min-price') {
				return priceA - priceB;
			}

			if (sortBy === 'max-price') {
				return priceB - priceA;
			}

			if (sortBy === 'oldest') {
				return createdA - createdB;
			}

			return createdB - createdA;
		});

		visible.forEach((card) => cardsRoot.appendChild(card));
	};

	filtersRoot.querySelectorAll('input, select').forEach((input) => {
		input.addEventListener('input', runFiltersWithoutJump);
		input.addEventListener('change', runFiltersWithoutJump);
	});

	const selectRoots = Array.from(filtersRoot.querySelectorAll('[data-zzz-custom-select]'));
	if (selectRoots.length > 0) {
		const closeAllMenus = () => {
			selectRoots.forEach((item) => {
				const trigger = item.querySelector('[data-zzz-select-trigger]');
				const menu = item.querySelector('[data-zzz-select-menu]');
				if (menu) {
					menu.setAttribute('hidden', 'hidden');
				}
				trigger?.setAttribute('aria-expanded', 'false');
			});
		};

		selectRoots.forEach((selectRoot) => {
			const trigger = selectRoot.querySelector('[data-zzz-select-trigger]');
			const menu = selectRoot.querySelector('[data-zzz-select-menu]');
			const label = selectRoot.querySelector('[data-zzz-select-label]');
			const hiddenInput = selectRoot.querySelector('input[type="hidden"][data-zzz-filter]');

			trigger?.addEventListener('click', () => {
				if (!menu) {
					return;
				}
				const isOpen = !menu.hasAttribute('hidden');
				closeAllMenus();
				if (!isOpen) {
					menu.removeAttribute('hidden');
					trigger.setAttribute('aria-expanded', 'true');
				}
			});

			menu?.querySelectorAll('button[data-value]').forEach((btn) => {
				btn.addEventListener('click', () => {
					if (hiddenInput) {
						hiddenInput.value = btn.getAttribute('data-value') || '';
					}
					if (label) {
						label.textContent = btn.textContent || '';
					}
					closeAllMenus();
					runFiltersWithoutJump();
				});
			});
		});

		document.addEventListener('click', (event) => {
			const target = event.target;
			if (!selectRoots.some((root) => root.contains(target))) {
				closeAllMenus();
			}
		});

		document.addEventListener('keydown', (event) => {
			if (event.key === 'Escape') {
				closeAllMenus();
			}
		});
	}

	runFiltersWithoutJump();
})();
